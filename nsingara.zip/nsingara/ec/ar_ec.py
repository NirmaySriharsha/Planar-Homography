import numpy as np
import cv2

# Import necessary functions

from loadVid import loadVid


# Q3.2
