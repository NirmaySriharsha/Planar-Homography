import numpy as np
import cv2

#Import necessary functions

from helper import loadVid



#Write script for Q3.1
